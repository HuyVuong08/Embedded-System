#include <stdio.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/timers.h"
#include "esp_system.h"
#include "esp_spi_flash.h"
#include "esp_freertos_hooks.h"
#include "driver/gpio.h"
#include "sdkconfig.h"

#define NUM_TIMERS 5
#define BLINK_GPIO CONFIG_BLINK_GPIO

char task1Param[12] = "task1Param";
char task2Param[12] = "task2Param";

/* An array to hold handles to the created timers. */
TimerHandle_t xTimers[ NUM_TIMERS ];
void vTimerCallback( TimerHandle_t xTimer )
{
    const uint32_t ulMaxExpiryCountBeforeStopping = 10;
    uint32_t ulCount;

    /* Optionally do something if the pxTimer parameter is NULL. */
    configASSERT( xTimer );

    /* The number of times this timer has expired is saved as the
    timer's ID.  Obtain the count. */
    ulCount = ( uint32_t ) pvTimerGetTimerID( xTimer );

    /* Increment the count, then test to see if the timer has expired
    ulMaxExpiryCountBeforeStopping yet. */
    ulCount++;

    /* If the timer has expired 10 times then stop it from running. */
    if( ulCount >= ulMaxExpiryCountBeforeStopping )
    {
        /* Do not use a block time if calling a timer API function
        from a timer callback function, as doing so could cause a
        deadlock! */
        xTimerStop( xTimer, 0 );
    }
    else
    {
        vTimerSetTimerID( xTimer, ( void * ) ulCount );
    }
}

void task1(void * parameter){
    printf((char *)parameter);
    /* loop forever */
    volatile uint32_t ul;
    while (1){
        for( ul = 0; ul < 10; ul++ )
	{
           printf("Ahihi\n");   
	}
	vTaskDelay(2000 / portTICK_PERIOD_MS);
        printf("task1 is ending\n");
    }
    vTaskDelete(NULL);
}

void task2(void * parameter){
    printf((char *)parameter);
    
    volatile uint32_t ul;
    while (1){
        for( ul = 0; ul < 50; ul++ )
	{
           printf("Ihaha\n");
	}
	vTaskDelay(3000 / portTICK_PERIOD_MS);
        printf("task2 is ending\n");
    }
    vTaskDelete(NULL);
}
 
void app_main()
 {
 long x;

     for( x = 0; x < NUM_TIMERS; x++ )
     {
         xTimers[ x ] = xTimerCreate
                   ( /* Just a text name, not used by the RTOS
                     kernel. */
                     "Timer",
                     /* The timer period in ticks, must be
                     greater than 0. */
                     ( 100 * x ) + 100,
                     /* The timers will auto-reload themselves
                     when they expire. */
                     pdTRUE,
                     /* The ID is used to store a count of the
                     number of times the timer has expired, which
                     is initialised to 0. */
                     ( void * ) 0,
                     /* Each timer calls the same callback when
                     it expires. */
                     vTimerCallback
                   );

         if( xTimers[ x ] == NULL )
         {
             /* The timer was not created. */
         }
         else
         {
            if( xTimerStart( xTimers[ x ], 0 ) != pdPASS )
            {
               
            }
         }
     }

     /* ...
     Create tasks here
     ... */
    xTaskCreate(task1, "task1", 10000, (void *)task1Param, 1, NULL);  
    xTaskCreate(task2, "task2", 10000, (void *)task2Param, 1, NULL);  

     /* Starting the RTOS scheduler will start the timers running
     as they have already been set into the active state. */
     vTaskStartScheduler();

     /* Should not reach here. */
}
	

